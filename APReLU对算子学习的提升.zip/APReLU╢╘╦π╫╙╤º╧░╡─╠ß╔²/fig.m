% A simple script to draw an Aprelu function flowchart in Matlab
figure;
% Define block positions [x y width height]
inputBlock = [1, 5, 2, 1];
posBlock = [0, 4, 1, 1];
negBlock = [2, 4, 1, 1];
meanPosBlock = [0, 3, 1, 1];
meanNegBlock = [2, 3, 1, 1];
concatBlock = [1, 2, 2, 1];
dense1Block = [1, 1, 2, 1];
batchNorm1Block = [1, 0, 2, 1];
reluBlock = [1, -1, 2, 1];
dense2Block = [1, -2, 2, 1];
batchNorm2Block = [1, -3, 2, 1];
sigmoidBlock = [1, -4, 2, 1];
reshapeScaleBlock = [1, -5, 2, 1];
outputBlock = [1, -6, 2, 1];

% Draw blocks
rectangle('Position', inputBlock, 'Curvature', 0.2, 'FaceColor', [0.8 0.8 1]);
rectangle('Position', posBlock, 'Curvature', 0.2, 'FaceColor', [0.8 1 0.8]);
rectangle('Position', negBlock, 'Curvature', 0.2, 'FaceColor', [1 0.8 0.8]);
rectangle('Position', meanPosBlock, 'Curvature', 0.2, 'FaceColor', [0.8 1 0.8]);
rectangle('Position', meanNegBlock, 'Curvature', 0.2, 'FaceColor', [1 0.8 0.8]);
rectangle('Position', concatBlock, 'Curvature', 0.2, 'FaceColor', [1 1 0.8]);
rectangle('Position', dense1Block, 'Curvature', 0.2, 'FaceColor', [0.8 0.8 1]);
rectangle('Position', batchNorm1Block, 'Curvature', 0.2, 'FaceColor', [0.8 1 0.8]);
rectangle('Position', reluBlock, 'Curvature', 0.2, 'FaceColor', [1 0.8 0.8]);
rectangle('Position', dense2Block, 'Curvature', 0.2, 'FaceColor', [1 1 0.8]);
rectangle('Position', batchNorm2Block, 'Curvature', 0.2, 'FaceColor', [0.8 0.8 1]);
rectangle('Position', sigmoidBlock, 'Curvature', 0.2, 'FaceColor', [0.8 1 0.8]);
rectangle('Position', reshapeScaleBlock, 'Curvature', 0.2, 'FaceColor', [1 0.8 0.8]);
rectangle('Position', outputBlock, 'Curvature', 0.2, 'FaceColor', [1 1 0.8]);

% Add labels
text(inputBlock(1)+0.5, inputBlock(2)+0.5, 'Input', 'HorizontalAlignment', 'Center');
text(posBlock(1)+0.5, posBlock(2)+0.5, 'Positive Part', 'HorizontalAlignment', 'Center');
text(negBlock(1)+0.5, negBlock(2)+0.5, 'Negative Part', 'HorizontalAlignment', 'Center');
text(meanPosBlock(1)+0.5, meanPosBlock(2)+0.5, 'Mean Pos', 'HorizontalAlignment', 'Center');
text(meanNegBlock(1)+0.5, meanNegBlock(2)+0.5, 'Mean Neg', 'HorizontalAlignment', 'Center');
text(concatBlock(1)+1, concatBlock(2)+0.5, 'Concatenate', 'HorizontalAlignment', 'Center');
text(dense1Block(1)+1, dense1Block(2)+0.5, 'Dense Linear', 'HorizontalAlignment', 'Center');
text(batchNorm1Block(1)+1, batchNorm1Block(2)+0.5, 'Batch Norm', 'HorizontalAlignment', 'Center');
text(reluBlock(1)+1, reluBlock(2)+0.5, 'ReLU', 'HorizontalAlignment', 'Center');
text(dense2Block(1)+1, dense2Block(2)+0.5, 'Dense Linear', 'HorizontalAlignment', 'Center');
text(batchNorm2Block(1)+1, batchNorm2Block(2)+0.5, 'Batch Norm', 'HorizontalAlignment', 'Center');
text(sigmoidBlock(1)+1, sigmoidBlock(2)+0.5, 'Sigmoid', 'HorizontalAlignment', 'Center');
text(reshapeScaleBlock(1)+1, reshapeScaleBlock(2)+0.5, 'Reshape & Scale', 'HorizontalAlignment', 'Center');
text(outputBlock(1)+1, outputBlock(2)+0.5, 'Output', 'HorizontalAlignment', 'Center');

axis equal;
axis off;
