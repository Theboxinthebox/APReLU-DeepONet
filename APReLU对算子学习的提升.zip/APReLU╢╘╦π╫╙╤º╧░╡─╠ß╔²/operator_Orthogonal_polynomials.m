function L_Phi = operator_Orthogonal_polynomials( Loc_u, operator_type, operator_paras, degree)

    if strcmp(operator_type, '2D_fLap_disk')
          alpha = operator_paras(1);
          M = size(Loc_u,1);
          [pt_cell, coeff_mat]=matrix_for_frac_Lap(Loc_u, alpha); 
         L_Phi = zeros(M, degree+1);
         for i = 1:M
             [t0,r0]=cart2pol(pt_cell{i}(:,1), pt_cell{i}(:,2));
             Phi = Orthogonal_polynomials([r0,t0], degree, 'unit_disk');
             L_Phi(i,:) = coeff_mat(i,:) * Phi;   
         end
     end
   