space_paras = [14, 2];
space_type = 'Orthogonal';
training_set(500, 8, 8, 6, '2D_fLap_disk', space_type,  space_paras);
test_set(500, 8, 8, 6, '2D_fLap_disk',  space_type, space_paras);