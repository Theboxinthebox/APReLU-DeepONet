% Problem 2: Solve the approximate solution in [0,2*pi] and display the fitting curve

% Define the differential equation
dy = @(x, y) cos(x);

% Initial conditions
x0 = 0;
y0 = 2;
xf = 2*pi; % Final value of x (2*pi)
h = 0.1; % Step size - adjust if needed for better accuracy

% Initialize values
x = x0:h:xf;
y = zeros(size(x));
y(1) = y0; % Initial condition

% Euler's Method
for i=1:(length(x)-1)
    y(i+1) = y(i) + h * dy(x(i), y(i));
end

% Plot the results
plot(x, y, 'b-'); % Blue line for the Euler approximate solution
hold on;
grid on;
xlabel('x');
ylabel('y');
title('Approximate Solution using Euler''s method');

% Compare with the analytical solution (if known) - not required but useful for illustration
% Say the analytical solution to y' = cos(x) with y(0) = 2 is y = 2 + sin(x)
% Plot the analytical solution for comparison
y_true = y0 + sin(x);
plot(x, y_true, 'r--'); % Red dashed line for the true solution
legend('Euler Approximation', 'True Solution');
