% Problem 1: Solve the approximate solution at x = 1.4

% Define the differential equation
dy = @(x, y) x^2 + y^2;

% Initial conditions
x0 = 1;
y0 = 1;
h = 0.1; % Step size
xf = 1.4; % Final value of x for which we need the solution

% Initialize values
x = x0:h:xf;
y = zeros(size(x));
y(1) = y0; % Initial condition at x = 1

% Euler's Method
for i=1:(length(x)-1)
    y(i+1) = y(i) + h * dy(x(i), y(i));
end

% The approximate solution at x = 1.4 is:
y(end)
