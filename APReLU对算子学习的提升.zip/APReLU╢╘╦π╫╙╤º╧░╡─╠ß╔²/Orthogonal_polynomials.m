function Phi = Orthogonal_polynomials( Loc_u, degree, domain_type)

     if strcmp(domain_type, 'unit_disk')
         Phi = Zp(Loc_u(:,1), Loc_u(:,2), degree);  % Loc_u 's in polar coordinate system
     end
   